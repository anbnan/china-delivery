function showOrderForm() {
  document.getElementById('orderModal').style.display = 'block';
}
function closeOrderForm() {
  document.getElementById('orderModal').style.display = 'none';
}
window.onclick = function(event) {
  const modal = document.getElementById('orderModal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
}
document.getElementById('order-form').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Ваш заказ отправлен!');
  closeOrderForm();
});
document.getElementById('contact-form').addEventListener('submit', function(e) {
  e.preventDefault();
  alert('Ваше сообщение отправлено!');
  this.reset();
});